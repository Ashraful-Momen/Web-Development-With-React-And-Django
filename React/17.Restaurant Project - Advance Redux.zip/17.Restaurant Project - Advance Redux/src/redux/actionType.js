export const ADD_COMMENTS = "ADD_COMMENTS";

export const LOAD_DISHES = "LOAD_DISHES"; // after load all dishes execute this function.
export const DISHES_LOADING = "DISHES_LOADING"; // show the spiner icon when dishes loading. 