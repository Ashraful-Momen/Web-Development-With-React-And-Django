//action Creation is function for pass into reducer...


import * as actionType from "./actionType";
import DISHES from "../data/dishes";

export const addCommnet = (author, rating, comment, dishesId) => {
  return {
    type: actionType.ADD_COMMENTS,
    payload: {
      author: author,
      rating: rating,
      comment: comment,
      dishesId: dishesId,
    },
  };
};

export const loadDishes = (dishes) =>{
  return {
    type:actionType.LOAD_DISHES,
    payload:dishes,
  }
}

export const dishLoading = () =>{
  return {
    type:actionType.DISHES_LOADING,
  }
}

export const fetchDishes = ()=>{
  return dispatch =>{
    dispatch(dishLoading());
    setTimeout(()=>{
      dispatch(loadDishes(DISHES)); // make this async cz when data come to this function it will take some time for showing the other loadingDishes() icon
    },2000)
  }
}
