import React from "react";
import { Nav, Navbar, NavbarBrand, NavLink, NavItem } from "reactstrap";
import "./Header.css";
// import Logo from '../../assets/brandLogo.jpg' ;
import Logo2 from "../../assets/brandLogo2.png"

const Header = () => {
	return (
		<div className="Navigation">
			<Navbar style={{ backgroundColor: "#e21b70", height: "70px" }} className="mx-auto">
				<NavbarBrand className="Brand ms-md-5" href="/" >
					
                    <img src={Logo2} alt="BrandLogo" style={{height:"50px", width:"50px" , borderRadius:"50%",}}/>
				</NavbarBrand>
				<Nav className="me-md-5">
					<NavItem>
						<NavLink className="NavLink">Something</NavLink>
					</NavItem>
				</Nav>
			</Navbar>
		</div>
	);
};

export default Header;
