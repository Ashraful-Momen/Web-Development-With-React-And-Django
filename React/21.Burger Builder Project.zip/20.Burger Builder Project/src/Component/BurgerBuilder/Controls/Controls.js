import React from "react";
import { Card, CardHeader, CardFooter, CardBody, Button } from "reactstrap";

const control = [
	{ label: "Salad", type: "Salad" },
	{ label: "Cheese", type: "Cheese" },
	{ label: "Meat", type: "Meat" },
];

const BuildControl = (props) => {
	return (
		<div className="d-flex">
			<div className="me-auto ms-5" style={{fontWeight:"bold",fontSize:"1.5rem"}}>{props.label}</div>
			<button className="btn btn-danger m-1">Less</button>
			<button className="btn btn-success m-1">More</button>
		</div>
	);
};

const Controls = (props) => {
	return (
		<div className="container ms-md-5" style={{ textAlign: "center" }}>
			<Card
				style={{
					marginTop: "30px",
					marginBottom: "30px",
					textAlign: "center",
				}}
			>
				<CardHeader
					style={{
						backgroundColor: "#e21b70",
						color: "white",
					}}
				>
					Add Ingredient
				</CardHeader>
				<CardBody>
                    {
                        control.map(item=>{
                            return <BuildControl
                            label={item.label}
                            type={item.type}
                            key={Math.random()}/>
                        })
                    }
                </CardBody>
				<CardFooter>Price: BDT</CardFooter>
			</Card>
		</div>
	);
};

export default Controls;
