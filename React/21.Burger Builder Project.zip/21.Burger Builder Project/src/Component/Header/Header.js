import React from "react";
import { Nav, Navbar, NavbarBrand,  NavItem } from "reactstrap";
import "./Header.css";
import {NavLink} from 'react-router-dom'
import Logo2 from "../../assets/brandLogo2.png"

const Header = () => {
	return (
		<div className="Navigation">
			<Navbar style={{ backgroundColor: "#e21b70", height: "70px" }} className="mx-auto">
				<NavbarBrand className="Brand ms-md-5" href="/" >
					
                    <img src={Logo2} alt="BrandLogo" style={{height:"50px", width:"50px" , borderRadius:"50%",}}/>
				</NavbarBrand>
				<Nav className="me-md-5">
					<NavItem className="mx-1">
						<NavLink to="/" className="NavLink">BurgerBuilder</NavLink>
					</NavItem>
					<NavItem>
						<NavLink className="mx-1" to="/order" className="NavLink">Orders</NavLink>
					</NavItem>
				</Nav>
			</Navbar>
		</div>
	);
};

export default Header;
