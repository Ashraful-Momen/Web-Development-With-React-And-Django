import React, { Component } from "react";
import Burger from "./Burger/Burger";
import Controls from "./Controls/Controls";
import { Modal, ModalHeader, ModalBody, ModalFooter, Button } from "reactstrap";
import Summery from "./Summary/Summary";
import { Navigate } from "react-router-dom";
// import { useNavigate } from "react-router-dom";

const INGREDIENT_PRICES = {
  Salad: 20,
  Cheese: 30,
  Meat: 50,
};

class BurgerBuilder extends Component {
  constructor(props) {
    super(props);
  }
  state = {
    ingredients: [
      { type: "Salad", amount: 0 },
      { type: "Cheese", amount: 0 },
      { type: "Meat", amount: 0 },
    ],
    totalPrice: 80,
    modalOpen: false,
    purchasable: false,
    onClickCheckout: false,
  };
  addIngredientHandle = (type) => {
    const ingredients = [...this.state.ingredients];
    const newPrice = this.state.totalPrice + INGREDIENT_PRICES[type];
    for (let item of ingredients) {
      if (item.type === type) {
        item.amount++;
      }
    }
    this.setState({
      ingredients: ingredients,
      totalPrice: newPrice,
    });

    this.updatePurchable(ingredients);
    // console.log(type);
  };
  removeIngredientHandle = (type) => {
    const ingredients = [...this.state.ingredients];
    const newPrice = this.state.totalPrice - INGREDIENT_PRICES[type];
    for (let item of ingredients) {
      if (item.type === type) {
        if (item.amount <= 0) return;
        item.amount--;
      }
    }
    this.setState({
      ingredients: ingredients,
      totalPrice: newPrice,
    });

    this.updatePurchable(ingredients);
    // console.log(type);
  };
  toggleModal = () => {
    this.setState({
      modalOpen: !this.state.modalOpen,
    });
  };
  updatePurchable = (ingredient) => {
    const sum = ingredient.reduce((sum, element) => {
      return sum + element.amount;
    }, 0);
    this.setState({
      purchasable: sum > 0, // return true or false
    });
  };
  handleCheckout = () => {
    this.setState({
      onClickCheckout: !this.state.onClickCheckout,
    });
  };

  render() {
    return (
      <div>
        <div className="d-flex flex-md-row flex-column">
          <Burger ingredients={this.state.ingredients} />
          <Controls
            ingredientAdded={this.addIngredientHandle}
            ingredientRemoved={this.removeIngredientHandle}
            price={this.state.totalPrice}
            toggleModal={this.toggleModal}
            purchasable={this.state.purchasable}
          />
        </div>
        <Modal isOpen={this.state.modalOpen}>
          <ModalHeader>Your Order Summery</ModalHeader>
          <ModalBody>
            <Summery ingredients={this.state.ingredients} />
            <h5>Total Price : {this.state.totalPrice.toFixed(0)} BDT</h5>
          </ModalBody>
          <ModalFooter>
            <Button color="success" onClick={this.handleCheckout}>
              Continue to CheckOut
            </Button>
            <Button color="secondary" onClick={this.toggleModal}>
              Cancel
            </Button>
          </ModalFooter>
          {this.state.onClickCheckout && (
            <Navigate to="/checkout" replace={true} />
          )}
          //Here's what happens in the line:
          {/* {this.state.onClickCheckout}: This part checks the value of the onClickCheckout state. If it is true, the condition evaluates to true.
&&: The logical "AND" operator is used to conditionally render the next part of the line.
<Navigate to="/checkout" replace={true}/>: If the condition (this.state.onClickCheckout) is true, the <Navigate> component is rendered. It is passed the to prop with the value "/checkout" to specify the destination route. The replace prop is set to true to replace the current entry in the history stack with the new entry.
In summary, when onClickCheckout is true, the line renders the <Navigate> component, which triggers navigation to the "/checkout" route. */}
        </Modal>
      </div>
    );
  }
}

export default BurgerBuilder;

//Advance and ALternative coding with Hooks:
// --------------------------------------------
// import React, { useState } from "react";
// import Burger from "./Burger/Burger";
// import Controls from "./Controls/Controls";
// import { Modal, ModalHeader, ModalBody, ModalFooter, Button } from "reactstrap";
// import Summary from "./Summary/Summary";
// import { useNavigate } from "react-router-dom";

// const INGREDIENT_PRICES = {
//   Salad: 20,
//   Cheese: 30,
//   Meat: 50,
// };

// const BurgerBuilder = () => {
//   const [ingredients, setIngredients] = useState([
//     { type: "Salad", amount: 0 },
//     { type: "Cheese", amount: 0 },
//     { type: "Meat", amount: 0 },
//   ]);
//   const [totalPrice, setTotalPrice] = useState(80);
//   const [modalOpen, setModalOpen] = useState(false);
//   const [purchasable, setPurchasable] = useState(false);
//   const navigate = useNavigate();

//   const addIngredientHandle = (type) => {
//     const updatedIngredients = [...ingredients];
//     const newPrice = totalPrice + INGREDIENT_PRICES[type];
//     for (let item of updatedIngredients) {
//       if (item.type === type) {
//         item.amount++;
//       }
//     }
//     setIngredients(updatedIngredients);
//     setTotalPrice(newPrice);
//     updatePurchable(updatedIngredients);
//   };

//   const removeIngredientHandle = (type) => {
//     const updatedIngredients = [...ingredients];
//     const newPrice = totalPrice - INGREDIENT_PRICES[type];
//     for (let item of updatedIngredients) {
//       if (item.type === type) {
//         if (item.amount <= 0) return;
//         item.amount--;
//       }
//     }
//     setIngredients(updatedIngredients);
//     setTotalPrice(newPrice);
//     updatePurchable(updatedIngredients);
//   };

//   const toggleModal = () => {
//     setModalOpen(!modalOpen);
//   };

//   const updatePurchable = (updatedIngredients) => {
//     const sum = updatedIngredients.reduce((sum, element) => {
//       return sum + element.amount;
//     }, 0);
//     setPurchasable(sum > 0);
//   };

//   const handleCheckout = () => {
//     navigate("/checkout");
//   };

//   return (
//     <div>
//       <div className="d-flex flex-md-row flex-column">
//         <Burger ingredients={ingredients} />
//         <Controls
//           ingredientAdded={addIngredientHandle}
//           ingredientRemoved={removeIngredientHandle}
//           price={totalPrice}
//           toggleModal={toggleModal}
//           purchasable={purchasable}
//         />
//       </div>
//       <Modal isOpen={modalOpen}>
//         <ModalHeader>Your Order Summary</ModalHeader>
//         <ModalBody>
//           <Summary ingredients={ingredients} />
//           <h5>Total Price: {totalPrice.toFixed(0)} BDT</h5>
//         </ModalBody>
//         <ModalFooter>
//           <Button color="success" onClick={handleCheckout}>
//             Continue to CheckOut
//           </Button>
//           <Button color="secondary" onClick={toggleModal}>
//             Cancel
//           </Button>
//         </ModalFooter>
//       </Modal>
//     </div>
//   );
// };

// export default BurgerBuilder;
