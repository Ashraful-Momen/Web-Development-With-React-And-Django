import React, { Component } from "react";
import { Button } from "reactstrap";

class CheckOut extends Component {
  state = {
    value: {
      deliveryAddress: "",
      phone: "",
      paymentType: "Cash On Delivery",
    },
  };

  goBack = () => {
    this.props.history.goBack();
  }

  render() {
    return (
      <div>
        <form>
          <textarea
            name="deliveryAddress"
            value={this.state.value.deliveryAddress}
            className="form-control"
            placeholder="Your Address"
          ></textarea>
          <br />
          <input
            name="phone"
            className="form-control"
            value={this.state.phone}
            placeholder="Phone Number"
          />
          <br />
          <select
            name="paymentType"
            value={this.state.paymentType}
            className="form-control"
          >
            <option value="Cash On Delivery">Cash On Delivery</option>
            <option value="Bkash">Bkash</option>
          </select>
          <br/>
          <Button style={{backgroundColor:"#D70F65"}}>Place Order</Button>
          <Button className="secondary ms-3" onClick={() => this.goBack()}>Cancel</Button>
        </form>
      </div>
    );
  }
}

export default CheckOut;



// import React, { Component } from "react";
// import { Button } from "reactstrap";

// class CheckOut extends Component {
  

//   state = {
//     value: {
//       deliveryAddress: "",
//       phone: "",
//       paymentType: "Cash On Delivery",
//     },
//   };

//   goBack = () => {
//     this.props.history.goBack("/");
//   };

//   render() {
//     return (
//       <div>
//         <form>
//           <textarea
//             name="deliveryAddress"
//             value={this.state.value.deliveryAddress}
//             className="form-control"
//             placeholder="Your Address"
//           ></textarea>
//           <br />
//           <input
//             name="phone"
//             className="form-control"
//             value={this.state.phone}
//             placeholder="Phone Number"
//           />
//           <br />
//           <select
//             name="paymentType"
//             value={this.state.paymentType}
//             className="form-control"
//           >
//             <option value="Cash On Delivery">Cash On Delivery</option>
//             <option value="Bkash">Bkash</option>
//           </select>
//           <br/>
//           <Button style={{backgroundColor:"#D70F65"}}>Place Order</Button>
//           <Button className="secondary ms-3" onClick={this.goBack}>Cancel</Button>
//         </form>
//       </div>
//     );
//   }
// }

// export default CheckOut;


