import * as actionType from './actionType';

export const addIngredient = (igtype)=>{
    return{
        type:actionType.ADD_INGREDIENT,
        payload:igtype
    }
}

export const removedIngredient = (igtype)=>{
    return{
        type:actionType.REMOVED_INGREDIENT,
        payload:igtype,
    }
}

export const updatePurchable = ()=>{
    return {
        type:actionType.UPDATE_PURSHABLE,
    }
}