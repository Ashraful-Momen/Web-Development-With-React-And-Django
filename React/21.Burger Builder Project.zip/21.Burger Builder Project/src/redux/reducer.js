import * as actionType from "./actionType";

const INGREDIENT_PRICES = {
	Salad: 20,
	Cheese: 30,
	Meat: 50,
};

const INITIAL_STATE = {
	ingredients: [
		{ type: "Salad", amount: 0 },
		{ type: "Cheese", amount: 0 },
		{ type: "Meat", amount: 0 },
	],

	totalPrice: 80,
	purchasable: false,
};

export const reducer = (state = INITIAL_STATE, action) => {
	const ingredients = [...state.ingredients];
	switch (action.type) {
		case actionType.ADD_INGREDIENT:
			for (let item of ingredients) {
				if (item.type === action.payload) {
					item.amount++;
				}
			}
			return {
				...state,
				ingredients: ingredients,
				totalPrice: state.totalPrice + INGREDIENT_PRICES[action.payload]
			};

		case actionType.REMOVED_INGREDIENT:
			const updatedIngredients = [...state.ingredients];
			const newPrice = state.totalPrice - INGREDIENT_PRICES[action.payload];
			for (let item of updatedIngredients) {
				if (item.type === action.payload) {
					if (item.amount <= 0) return state;
					item.amount--;
				}
			}
			return {
				...state,
				ingredients: updatedIngredients,
				totalPrice: newPrice,
			};

		case actionType.UPDATE_PURSHABLE:
			const sum = state.ingredients.reduce((sum, element) => {
				return sum + element.amount;
			}, 0);
			return {
				...state,
				purchasable: sum > 0,
			};

		default:
			return { ...state };
	}
};
