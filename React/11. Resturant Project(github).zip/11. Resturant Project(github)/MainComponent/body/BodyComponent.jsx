import React from "react";
import Menu from "./Menu";


function BodyComponent() {
	return (
		<div>
      <Menu/>
		</div>
	);
}

export default BodyComponent;
