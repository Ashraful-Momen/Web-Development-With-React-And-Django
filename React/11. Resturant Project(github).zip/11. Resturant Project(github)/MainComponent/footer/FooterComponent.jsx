import React from "react";

function FooterComponent() {
	return <div>FooterComponent</div>;
}

export default FooterComponent;
