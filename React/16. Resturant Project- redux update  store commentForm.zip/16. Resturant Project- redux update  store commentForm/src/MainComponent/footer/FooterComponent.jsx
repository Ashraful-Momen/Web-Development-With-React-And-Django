import React from "react";

function FooterComponent() {
	return (
		<div className="footer">
			<div className="Container">
				<div className="row ">
					<div >
						<p >KFC ResTaurant &#169; CopyRight</p>
					</div>
				</div>
			</div>
		</div>
	);
}

export default FooterComponent;
