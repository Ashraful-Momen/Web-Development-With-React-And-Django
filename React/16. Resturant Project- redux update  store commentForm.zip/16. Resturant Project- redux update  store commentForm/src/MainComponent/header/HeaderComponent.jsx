import React from "react";
import NavigationComponent from "./NavigationComponent";

function HeaderComponent() {
	return (
		<div>
			<NavigationComponent />
			 
		</div>
	);
}

export default HeaderComponent;
