const COMMENTS = [


    {
        dishesId: 0,
        id: 0,
        rating: 5,
        comment: "ajdoifjaoksfj asdjfakd sf",
        author: "Shuvo",
        date: "2023-10-16",
    },

    {
        dishesId: 0,
        id: 1,
        rating: 5,
        comment: "ajdoifjaoksfj asdjfakd sf",
        author: "Shuvo",
        date: "2023-10-16",
    },
    {
        dishesId: 0,
        id: 2,
        rating: 5,
        comment: "ajdoifjaoksfj asdjfakd sf",
        author: "Shuvo",
        date: "2023-10-16",
    },
    {
        dishesId: 1,
        id: 3,
        rating: 5,
        comment: "ajdoifjaoksfj asdjfakd sf",
        author: "Shuvo",
        date: "2023-10-16",
    },

    {
        dishesId: 1,
        id: 4,
        rating: 5,
        comment: "ajdoifjaoksfj asdjfakd sf",
        author: "Shuvo",
        date: "2023-10-16",
    },
    {
        dishesId: 1,
        id: 5,
        rating: 5,
        comment: "ajdoifjaoksfj asdjfakd sf",
        author: "Shuvo",
        date: "2023-10-16",
    },
    {
        dishesId: 2,
        id: 6,
        rating: 5,
        comment: "ajdoifjaoksfj asdjfakd sf",
        author: "Shuvo",
        date: "2023-10-16",
    },

    {
        dishesId: 2,
        id: 7,
        rating: 5,
        comment: "ajdoifjaoksfj asdjfakd sf",
        author: "Shuvo",
        date: "2023-10-16",
    },
    {
        dishesId: 2,
        id: 8,
        rating: 5,
        comment: "ajdoifjaoksfj asdjfakd sf",
        author: "Shuvo",
        date: "2023-10-16",
    },
    {
        dishesId: 3,
        id: 9,
        rating: 5,
        comment: "ajdoifjaoksfj asdjfakd sf",
        author: "Shuvo",
        date: "2023-10-16",
    },

    {
        dishesId: 3,
        id: 10,
        rating: 5,
        comment: "ajdoifjaoksfj asdjfakd sf",
        author: "Shuvo",
        date: "2023-10-16",
    },
    {
        dishesId: 3,
        id: 11,
        rating: 5,
        comment: "ajdoifjaoksfj asdjfakd sf",
        author: "Shuvo",
        date: "2023-10-16",
    },
    


]

export default COMMENTS;