import DISHES from "../data/dishes";
import COMMENTS from "../data/COMMENTS";

const initState = {
	dishes: DISHES,
	comments: COMMENTS,
	check: "Working",
};



export const Reducer = (state = initState, action) => {
	console.log(action);
	return state;
};


