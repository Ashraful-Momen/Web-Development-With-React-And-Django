import { combineReducers } from "redux";
import * as actionType from '../redux/actionType';
import { InitialContactForm } from "./form";
import { createForms } from "react-redux-form";

//thunk function logic is here below=>

const dishReducer= (dishState={isLoading:false,errorMsg:null,dishes:[]}, action) =>{
	switch(action.type){
		case actionType.DISHES_LOADING:
			return{
				...dishState,
				isLoading:true,
				dishesh:[],
				errorMsg:null,
			}
		case actionType.LOAD_DISHES:
			return{
				...dishState,
				isLoading:false,
				dishes:action.payload , // actionCreators.js => this value pass all dishes form fetchDishes(axios=>loadDishes(action.value pass the dishes))
				errorMsg:null,
			}

		case actionType.DISHES_FAILD:
			return{
				...dishState,
				isLoading:false,
				dishes:[],
				errorMsg:action.payload,
			}

		default:
			return dishState;

	}
	
}


const commentReducer = (commentState = {isLoading:true,comments:[]}, action) => {
	switch(action.type){
		case actionType.LOAD_COMMENTS:
			return{
				...commentState,
				isLoading:false,
				comments:action.payload // this comment comes from actionCreators.js fetch(axios=>dispatch(loadComments(response.comments=>comments)))
			}
		case actionType.COMMENTS_LOADING:
			return{
				...commentState,
				isLoading:true,
				comments:[]
			}
		case actionType.ADD_COMMENTS:
			let comment = action.payload;
			return{
				...commentState,
				commnets:commentState.comments.concat(comment),
			}
		
		default:
			return commentState;

	}
  };


export const Reducer = combineReducers ({
		dishes:dishReducer,
		comments:commentReducer,
		...createForms ({
			feedback: InitialContactForm, // pass the contact state value in here and make it state to contact form...
		})
	});






