export const InitialContactForm = {
    firtname: "",
    lastname: "",
    telnum: "",
    email: "",
    agree:false,
    contactType:"Tel.",
    message:"",

}