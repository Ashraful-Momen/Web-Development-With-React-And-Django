//action Creation is function for pass into reducer...

import * as actionType from "./actionType";
import axios from "axios";
import { baseUrl } from "./baseUrl";

export const addCommnet = (author, rating, comment, dishesId) => dispatch=> {
  const newComment= {
    author: author,
    rating: rating,
    comment: comment,
    dishesId: dishesId,
  }
  newComment.date = new Date().toISOString();

  axios.post(baseUrl+"comments",newComment)
  .then(response=>response.data)
  .then(comment=>dispatch(commentConcat(comment)))
};

//add comments =>
export const commentConcat = (comment) =>({
  type: actionType.ADD_COMMENTS,
  payload:comment,

})

export const loadComments = (comments) =>{
  return{
    type: actionType.LOAD_COMMENTS,
    payload:comments,
  }
}

export const commentsLoading= () =>{
  return{
    type: actionType.COMMENTS_LOADING,
  }
}

export const fetchComments = () =>{
  return (dispatch)=>{
    dispatch(commentsLoading()),

    axios.get(baseUrl+"comments")
    .then(response=>response.data)
    .then(comments=>dispatch(loadComments(comments)))
  }
}

export const loadDishes = (dishes) => {
  return {
    type: actionType.LOAD_DISHES,
    payload: dishes,
  };
};

export const dishLoading = () => {
  return {
    type: actionType.DISHES_LOADING,
  };
};

export const faildDishes = (errorMsg)=>{
  return {
    type:actionType.DISHES_FAILD,
    payload:errorMsg,
  }
}

export const fetchDishes = () => {
  return (dispatch) => {
    dispatch(dishLoading());
  

    axios
      .get(baseUrl + "dishes")
      .then((response) => response.data)
      .then((dishes) => dispatch(loadDishes(dishes)))
      .catch(error=>dispatch(faildDishes(error.message)))
  };
};
