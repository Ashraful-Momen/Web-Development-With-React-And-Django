export const ADD_COMMENTS = "ADD_COMMENTS";

export const LOAD_COMMENTS= "LOAD_COMMENTS"; //1.get all comment from json servers when loaded comments
export const COMMENTS_LOADING = "COMMENST_LOADING";//2. show the loading icon in commnets 

export const LOAD_DISHES = "LOAD_DISHES"; // after load all dishes execute this function.
export const DISHES_LOADING = "DISHES_LOADING"; // show the spiner icon when dishes loading. 
export const DISHES_FAILD = "DISHES_FAILD"// if loading faild dishes 