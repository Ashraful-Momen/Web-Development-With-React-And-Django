import React, { Component } from "react";
import MenuItem from "./MenuItem";
import DishDetail from "./DishDetail";
import { Alert, Button, CardColumns, Modal, ModalFooter } from "reactstrap";
import {connect} from 'react-redux';
import * as actionCreator from '../../redux/actionCreator' //redux thunk 1.here pass all dispatch function 
import Loading from './Loading';



const mapStateToProps = (state) =>{
	return {
		dishes:state.dishes,
		comments:state.comments,
	}
}
//mapDispatchToProps() this function comes from CommentForm.js=>
const mapDispatchToProps = (dispatch) =>{
	return {
	  addComment:(author,rating,comment,dishesId) =>{
		dispatch(actionCreator.addCommnet(author,rating,comment,dishesId));
	  },
	  fetchDishes:()=> dispatch(actionCreator.fetchDishes()), //redux thunk 2. pass loadDishes() and dishLoading();
	  fetchComments:()=>dispatch(actionCreator.fetchComments()),//***comments: from reducer.js fetchComments() pass all to this Class...loadComments() and commentsLaoding()
	}
  }

class Menu extends Component {
	//   constructor(props) {
	//     super(props);
	//     this.state = {
	//       dishes: DISHES,
	//       selectedDish: null
	//     };
	//   }
	state = {
		
		selectedDish: null,
		openModal: false,
	};
	

	onSelected = (dish) => {
		
		
		this.setState({ selectedDish: dish });
		this.setState({
			openModal: true,
		});
	};

	toggleModal = () => {
		this.setState({
			openModal: !this.state.openModal,
		});
	};
	//redux.thunk 4.=> until call fetchDish() from reducer dishes not showing on menu > so , use componentDidMount(pass the ->fetchDishe() , for calling)
	componentDidMount(){
		this.props.fetchDishes();
		this.props.fetchComments();
	}

	render() {

		document.title="Menu"
		// const { dishes, selectedDish } = this.state;
		// console.log(this.props);

		//5.redux.thunk 5. => if the isLoading True then show the loading component , else { execute.}
		if(this.props.dishes.isLoading){
			return (<Loading/>)
		}
		else if(this.props.dishes.errorMsg!=null){ // error Msg if dishes can't load from server....
			return(
				<Alert color="danger" >{this.props.dishes.errorMsg} </Alert> // if dish can't load from server...
			)
		}
		else{
			const menu = this.props.dishes.dishes.map((dish) => ( //redux thunk 3.here this.props.dishes -> has 2 property(isLoading,dishes[]<-if the loadDishesh() call then all dishes pass this emty array) which comes from reducer function
			<MenuItem dish={dish} key={dish.id} onSelected={this.onSelected} />
		));

		let dishDetail=null;
		
		if (this.state.selectedDish != null) {
			const comments = this.props.comments.comments.filter(comment => {
			  
			  return comment.dishesId === this.state.selectedDish.id;
			});
			// console.log(this.props);
				dishDetail = <DishDetail selectedDish={this.state.selectedDish} comments={comments} addComment={this.props.addComment} commmentsIsLoading={this.props.comments.isLoading}/>;
		  }
		// dishDetail = this.state.selectedDish ? (<DishDetail selectedDish={this.state.selectedDish} />) : null;

		return (
			<div className="Container">
				<div className="row">
					<div className="col-5 offset-3">{menu}</div>
					<div className="col-7">
						<Modal isOpen={this.state.openModal}>
							{dishDetail}
							
							<ModalFooter>
								<Button
									onClick={this.toggleModal}
									className="btn-outline-warning"
								>
									Close
								</Button>
							</ModalFooter>
						</Modal>
					</div>
				</div>
			</div>
		);
		}

		
	}
}

export default connect(mapStateToProps,mapDispatchToProps) (Menu);
