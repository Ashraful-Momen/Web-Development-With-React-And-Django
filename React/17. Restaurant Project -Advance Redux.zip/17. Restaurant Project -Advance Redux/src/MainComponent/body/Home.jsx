import React, { Component } from "react";
import LoadComponent from "./LoadComponent";
import Loading from "./Loading";

class Home extends Component {


	render() {
		document.title = "KFC Resturant";
		return <div>Home
			<div>
				<Loading/>
			</div>
		</div>;
	}
}

export default (Home);
