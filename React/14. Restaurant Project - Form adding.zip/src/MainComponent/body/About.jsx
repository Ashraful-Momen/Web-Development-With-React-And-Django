import React from 'react'

const About = () => {
  document.title="About";
  return (
    <div>About</div>
  )
}

export default About