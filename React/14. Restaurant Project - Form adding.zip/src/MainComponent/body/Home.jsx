import React from 'react'

const Home = () => {
  document.title="KFC Resturant"
  return (
    <div>Home</div>
  )
}

export default Home;