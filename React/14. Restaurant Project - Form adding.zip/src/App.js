import './App.css';
import MainComponent from './MainComponent/MainComponent';

function App() {
  return (
    <div className="App">
      <MainComponent/>
    </div>
  );
}

export default App;