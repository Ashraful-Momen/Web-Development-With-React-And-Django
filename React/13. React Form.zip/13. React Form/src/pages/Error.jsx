import React from 'react'

const Error = () => {
  return (
    <div>
        <h2>404: Page Not Found!</h2>
    </div>
  )
}

export default Error
