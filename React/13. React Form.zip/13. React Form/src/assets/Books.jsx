const Books =  [
    { id:1, bookName: "1980", writer: "I don't know" , details: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat corrupti vel aliquid quibusdam, inventore consectetur." },
    { id:2, bookName: "Algorithm", writer: "ALkhirmi", details: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat corrupti vel aliquid quibusdam, inventore consectetur." }, 
    { id:3, bookName: "DSA", writer: "don't Know", details: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat corrupti vel aliquid quibusdam, inventore consectetur." }, 
  ]

  export default Books;