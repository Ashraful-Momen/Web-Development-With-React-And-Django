import React from "react";

function SingIn(){
    return <h3>Sing In</h3>
}

export default SingIn;