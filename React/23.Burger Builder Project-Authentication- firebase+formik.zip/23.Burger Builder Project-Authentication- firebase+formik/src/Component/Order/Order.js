import React, { Component } from "react";
import { connect } from "react-redux";
import { fetchOrder } from "../../redux/actionCreators";
import SingleOrder from "./SingleOrder";
import  Spinner  from "../Spinner/Spinner";

const mapStateToProps = (state) => {
	return {
		orders: state.orders,
		orderLoading: state.orderLoading,
		orderError: state.orderError,
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
		fetchOrder: () => dispatch(fetchOrder()),
	};
};

class Order extends Component {
	componentDidMount() {
		this.props.fetchOrder(); // for calling this function...
	}

	componentDidUpdate() {
		// console.log(this.props); // check that data is coming from reducer function or not...
	}



	render() {
    let orders = null
    if(this.props.orderError){
      orders= <p style={{
        border: "1px solid grey",
        boxShadow: "1px 1px #888888",
        borderRadius: "5px",
        padding: "5px",
        marginRight:"5px"
      }}>Sorry Failed to Laod the Orders!</p>
    }
    else{
      if(this.props.orders.length === 0){
        orders= <p style={{
          border: "1px solid grey",
          boxShadow: "1px 1px #888888",
          borderRadius: "5px",
          padding: "5px",
          marginRight:"5px"
        }}>You have no Orders!</p>
      }
      else{
        // console.log(this.props.orders.length);
        orders = this.props.orders.map((order)=>{
          return (
            <SingleOrder order={order} key={order.id}/>
          )
        })

      }
      
    } 

		return(
    <div>{this.props.orderLoading? <Spinner/>: orders}</div>
    );
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(Order);
