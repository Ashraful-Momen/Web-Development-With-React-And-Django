
import React from "react";
import Header from "./Header/Header.js";
import BurgerBuilder from "./BurgerBuilder/BurgerBuilder";
import { Routes, Route, Link ,withRouter} from "react-router-dom";
import Order from "./Order/Order.js";
import CheckOut from "./Order/CheckOut/CheckOut.js";
import Auth from "./Auth/Auth.js";

const Main = (props) => {
  return (
    <div>
      <Header />
      <div className="container">
        <Routes>
          <Route path="/" element={<BurgerBuilder />}></Route>
          <Route path="/order" element={<Order />}></Route>
          <Route path="/checkout" element={<CheckOut />} ></Route>
          <Route path="/auth" element={<Auth/>}> </Route>
          {/* <Route path="/checkout" component={CheckOut} /> */}
        </Routes>
      </div>
    </div>
  );
};

export default Main;


