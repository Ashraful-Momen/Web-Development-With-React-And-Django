import React, { Component } from "react";
import { Formik } from "formik";
import { auth } from "../../redux/authActionCreators";
import {connect} from 'react-redux';


const mapDispatchToProps=(dispatch) =>{
    return {
        auth: (email, password, mode)=> dispatch=>(auth(email,password,mode))
    }
}

class Auth extends Component {
	state = {
		mode: "Sing Up",
	};
	switchModeHandler = () => {
		this.setState({
			mode: this.state.mode === "Sing Up" ? "LogIn" : "Sing Up",
		});
	};
	render() {
		return (
			<div>
				<Formik
					initialValues={{
						email: "",
						passWord: "",
						confirmPassword: "",
					}}
					onSubmit={(values) => {
						// console.log(values);
                        this.props.auth(values.email,values.passWord, this.state.mode);
					}}
					validate={(values) => {
						const errors = {};

						if (!values.email) {
							errors.email = "Required!"; // email input field empty
						} else if (
							!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/i.test(
								values.email,
							)
						) {
							errors.email = "Invalid Email!";
						}

						if (!values.passWord) {
							errors.passWord = "Required!";
						} else if (values.passWord.length < 4) {
							errors.passWord = "Password Should be at least 4 Characters!";
						}

						if (this.state.mode === "Sing Up") {
							if (!values.confirmPassword) {
								errors.confirmPassword = "Requried!";
							} else if (values.confirmPassword !== values.passWord) {
								errors.confirmPassword = "Password Should be matched!";
							}
						}

						// console.log(`Errors =>`, errors);
						return errors;
					}}
				>
					{({ values, handleChange, handleSubmit, errors }) => (
						<div
							style={{
								border: "1px solid",
								padding: "15px",
								borderRadius: "5px",
							}}
						>
							<button
								style={{
									backgroundColor: "#D70F64",
									color: "white",
									width: "100%",
								}}
								className="btn btn-lg"
								onClick={this.switchModeHandler}
							>
								Switch To {this.state.mode === "Sing Up" ? "LogIn" : "Sing Up"}{" "}
							</button>
							<br />
							<br />
							<form onSubmit={handleSubmit}>
								<input
									className="form-control"
									name="email"
									placeholder="Type Your Email"
									value={values.email}
									onChange={handleChange}
								/>
								<span style={{ color: "red" }}>{errors.email}</span>
								<br />
								<input
									className="form-control"
									name="passWord"
									placeholder="Password"
									value={values.passWord}
									onChange={handleChange}
								/>
								<span style={{ color: "red" }}>{errors.passWord}</span>
								<br />
								{this.state.mode === "Sing Up" ? (
									<div>
										{" "}
										<input
											className="form-control"
											name="confirmPassword"
											placeholder="RePassword"
											value={values.confirmPassword}
											onChange={handleChange}
										/>
										<span style={{ color: "red" }}>
											{errors.confirmPassword}
										</span>
										<br />
									</div>
								) : null}
								<button type="submit" className="btn btn-success">
									{this.state.mode === "Sing Up" ? "Sing Up" : "LogIn"}
								</button>
							</form>
						</div>
					)}
				</Formik>
			</div>
		);
	}
}

export default connect(null,mapDispatchToProps) (Auth);
