import * as actionType from './actionType';
import axios from 'axios';

//firebase : https://firebase.google.com/docs/reference/rest/auth#section-create-email-password


export const auth=(email,password,mode) => {

    return(dispatch=>{
        const authData={
            email:email,
            password:password,
            returnSecureToken:true, // according to firebase.
        }
        let authUrl=null;

        if(mode ==="Sing Up"){
            authUrl= "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=";
        }
        else{
            authUrl = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=";
        }

        const API_KEY="AIzaSyDVbB5Z2Lbzj4LsY_ag2b4S0YVzoVa-MEc";
        dispatch (axios.post(authUrl+API_KEY, authData)
        .then(response=>console.log(response))
        .catch(error=>console.log(error)))
    })
}