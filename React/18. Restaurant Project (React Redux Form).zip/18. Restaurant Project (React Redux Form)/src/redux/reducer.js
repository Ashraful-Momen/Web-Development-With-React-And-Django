

import COMMENTS from "../data/COMMENTS";
import { combineReducers } from "redux";
import * as actionType from '../redux/actionType';
import { InitialContactForm } from "./form";
import { createForms } from "react-redux-form";

//thunk function logic is here below=>

const dishReducer= (dishState={isLoading:false,dishes:[]}, action) =>{
	switch(action.type){
		case actionType.DISHES_LOADING:
			return{
				...dishState,
				isLoading:true,
				dishesh:[]
			}
		case actionType.LOAD_DISHES:
			return{
				...dishState,
				isLoading:false,
				dishes:action.payload , // this value pass all dishes form fetchDishes(loadDishes(action.value pass the dishes))
			}


		default:
			return dishState;

	}
	
}


const commentReducer = (commentState = COMMENTS, action) => {
	switch(action.type){
		case actionType.ADD_COMMENTS:
			let comment = action.payload;
			comment.id = commentState.length;
			comment.date = new Date().toDateString();
			console.log(comment);
			return commentState.concat(comment);
		
		default:
			return commentState;

	}
  };


export const Reducer = combineReducers ({
		dishes:dishReducer,
		comments:commentReducer,
		...createForms ({
			feedback: InitialContactForm, // pass the contact state value in here and make it state to contact form...
		})
	});






