
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSpinner } from '@fortawesome/free-solid-svg-icons';

const Loading = () => {
  return (
    <div className='col-12' style={{ padding: '60px' }}>
      
      <FontAwesomeIcon icon={faSpinner} spin size="xxl" className=''/>
     
    </div>
  );
};

export default Loading;

