const DISHES = [
	{
		id: 0,
		name: "Ginger-Burger",
		image: "https://media.istockphoto.com/id/1332013247/photo/tasty-hamburger-with-french-fries.webp?b=1&s=170667a&w=0&k=20&c=quLpaNbLuuAZT6GD2gNwlHej0DANXUYtbvKJPpct1nY=",
		category: "meal",
		label: "Hot",
		price: "199",
		featured:true,
		description: "loremajsefjasd fjasd fas jdfl;ka jsdflk aslkdf alk;sd fasdjf",
		
	},
	{
		
		id: 1,
		name: "Beaf BBQ",
		image: "https://media.istockphoto.com/id/1410844723/photo/delicious-juicy-cheeseburgers-served-with-french-fries.webp?b=1&s=170667a&w=0&k=20&c=OVYITEDJ_Xa_ZZHPoo0gHosya0uuvrDpmAZxdnH5DLM=",
		category: "meal",
		label: "Hot",
		price: "350$",
		featured:true,
		description: "loremajsefjasd fjasd fas jdfl;ka jsdflk aslkdf alk;sd fasdjf",
		// comments: [
			

		// ],
	},
	{
		id: 2,
		name: "Soft Burger",
		image: "https://media.istockphoto.com/id/1448322070/photo/fresh-tasty-burger-on-wood-table.webp?b=1&s=170667a&w=0&k=20&c=0x4WY-pc5e0f1qeM2Rs9im8CELp4F8k4xtCGaE29t24=",
		category: "meal",
		label: "Hot",
		price: "556$",
		featured:false,
		description: "loremajsefjasd fjasd fas jdfl;ka jsdflk aslkdf alk;sd fasdjf",
		// comments: [
			

		// ],
	},
	{
		id: 3,
		name: "Chawmin-Chinese",
		image: "https://media.istockphoto.com/id/1332013247/photo/tasty-hamburger-with-french-fries.webp?b=1&s=170667a&w=0&k=20&c=quLpaNbLuuAZT6GD2gNwlHej0DANXUYtbvKJPpct1nY=",
		category: "meal",
		label: "Hot",
		price: "556$",
		featured:false,
		description: "loremajsefjasd fjasd fas jdfl;ka jsdflk aslkdf alk;sd fasdjf",
		// comments: [
		

		// ],
	},

];


export default DISHES;