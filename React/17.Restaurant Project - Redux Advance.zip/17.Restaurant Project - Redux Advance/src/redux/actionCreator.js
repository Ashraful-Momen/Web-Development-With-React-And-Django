import * as actionType from "./actionType";

export const actionCommnet = (author, rating, comment, dishesId) => {
  return {
    type: actionType.ADD_COMMENTS,
    payload: {
      author: author,
      rating: rating,
      comment: comment,
      dishesId: dishesId,
    },
  };
};

// export const actionCommnet = (author,rating,comment,dishesId)=>({
//     type:actionType.ADD_COMMENTS,
//         payload:{
//             author:author,
//             rating:rating,
//             comment:comment,
//             dishesId:dishesId,
//         }
// })
