import React, { Component } from "react";
import MenuItem from "./MenuItem";
import DishDetail from "./DishDetail";
import { Button, CardColumns, Modal, ModalFooter } from "reactstrap";
import {connect} from 'react-redux';
import * as actionCreator from '../../redux/actionCreator'


const mapStateToProps = (state) =>{
	return {
		dishes:state.dishes,
		comments:state.comments,
	}
}
//mapDispatchToProps() this function comes from CommentForm.js=>
const mapDispatchToProps = (dispatch) =>{
	return {
	  addComment:(author,rating,comment,dishesId) =>{
		dispatch(actionCreator.actionCommnet(author,rating,comment,dishesId));
	  },
	  //deleteComment
	}
  }

class Menu extends Component {
	//   constructor(props) {
	//     super(props);
	//     this.state = {
	//       dishes: DISHES,
	//       selectedDish: null
	//     };
	//   }
	state = {
		
		selectedDish: null,
		openModal: false,
	};
	

	onSelected = (dish) => {
		
		
		this.setState({ selectedDish: dish });
		this.setState({
			openModal: true,
		});
	};

	toggleModal = () => {
		this.setState({
			openModal: !this.state.openModal,
		});
	};

	render() {

		document.title="Menu"
		// const { dishes, selectedDish } = this.state;
		// console.log(this.props);

		const menu = this.props.dishes.map((dish) => (
			<MenuItem dish={dish} key={dish.id} onSelected={this.onSelected} />
		));

		let dishDetail=null;
		
		if (this.state.selectedDish != null) {
			const comments = this.props.comments.filter(comment => {
			  
			  return comment.dishesId === this.state.selectedDish.id;
			});
			// console.log(this.props);
				dishDetail = <DishDetail selectedDish={this.state.selectedDish} comments={comments} addComment={this.props.addComment} />;
		  }
		// dishDetail = this.state.selectedDish ? (<DishDetail selectedDish={this.state.selectedDish} />) : null;

		return (
			<div className="Container">
				<div className="row">
					<div className="col-5 offset-3">{menu}</div>
					<div className="col-7">
						<Modal isOpen={this.state.openModal}>
							{dishDetail}
							
							<ModalFooter>
								<Button
									onClick={this.toggleModal}
									className="btn-outline-warning"
								>
									Close
								</Button>
							</ModalFooter>
						</Modal>
					</div>
				</div>
			</div>
		);
	}
}

export default connect(mapStateToProps,mapDispatchToProps) (Menu);
