import react , {Component} from 'react';
import fetch from 'cross-fetch'; 
import axios from 'axios';

class App extends Component {
  set = {
    dishes:null,
    errorMsg: null,
  }

  componentDidMount(){

    console.log("ComponentDidMount",this.state);
    
    //get____________________________________________
    axios.get('http://localhost:3001/dishes',   {
      "name": "chips",
      "price": "$20"
    } )
    .then(response=>response.data)
    .then(data=> {
      this.setState({
        dishes:data,
      })
    })
    .catch(error=>{
      this.setState({
        errorMsg:error.message,
      })
    });
    //create____________________________________________
    // axios.post('http://localhost:3001/dishes',   {
    //   "name": "chips",
    //   "price": "$20"
    // } )
    // .then(response=>response.data)
    // .then(data=> console.log(data));

    //Updtae____________________________________________

    // axios.put('http://localhost:3001/dishes/8',   {
    //   "name": "burger",
    //   "price": "$30"
    // } )
    // .then(response=>response.data)
    // .then(data=> console.log(data));

    //Delete______________________________________

    // axios.delete('http://localhost:3001/dishes/8',   {
    //   "name": "burger",
    //   "price": "$30"
    // } )



   
  }

  componentDidUpdate(){
    console.log("Updated",this.state);
  }

  render()
  {
    return (
      <div >
       
      </div>
    );
  }
 
}

export default App;
