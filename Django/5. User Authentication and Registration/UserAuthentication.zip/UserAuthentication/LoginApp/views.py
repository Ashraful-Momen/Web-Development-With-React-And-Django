from django.shortcuts import render
# from LoginApp.forms import UserInfo,UserForm
from LoginApp.forms import UserInfoForm,UserForm


#for login/logout: 
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from django.urls import reverse

from django.contrib.auth.models import User

# Create your views here.

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from LoginApp.models import UserInfo  # Make sure you import the UserInfo model


# @login_required #for login required to show the view
def index(request):
    dictionary = {}

    if request.user.is_authenticated:
        current_user = request.user

        # Fetch user basic info
        user_basic_info = User.objects.get(pk=current_user.id)

        # Fetch user more info using UserInfo model
        user_more_info = UserInfo.objects.get(user__pk=current_user.id)
        # try:
        #     user_more_info = UserInfo.objects.get(user__pk=current_user.id)
        # except UserInfo.DoesNotExist:
        #     user_more_info = None

        dictionary = {'user_basic_info': user_basic_info, 'user_more_info': user_more_info}

    return render(request, 'LoginApp/index.html', context=dictionary)




def register(request):
    dictionary = {}
    registered = False

    if request.method == 'POST':
        user_form = UserForm(data=request.POST)
        user_info_form = UserInfoForm(data=request.POST)  # Use UserInfoForm here

        if user_form.is_valid() and user_info_form.is_valid():
            user = user_form.save()
            user.set_password(user.password)
            user.save()

            user_info = user_info_form.save(commit=False)
            user_info.user = user

            if 'profile_pic' in request.FILES:
                user_info.profile_pic = request.FILES['profile_pic']

            user_info.save()

            registered = True

    else:
        user_form = UserForm()
        user_info_form = UserInfoForm()  # Use UserInfoForm here

    dictionary = {'user_form': user_form, 'user_info_form': user_info_form, 'registered': registered}

    return render(request, 'LoginApp/register.html', context=dictionary)



def login_page(request):
    return render(request,'LoginApp/login.html')

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('user_name')
        password = request.POST.get('password')

        #Authentication:
        user = authenticate(username=username,password=password)

        if user: 
            if user.is_active:
                login(request,user)
                return HttpResponseRedirect(reverse('LoginApp:index'))
            else:
                return HttpResponse('Account is not active')
        
        else:
            return HttpResponse('Login Details worng!!!')
    
    else:
        return render(request,'LoginApp/index.html',context={})

@login_required #user_logout works only when user logged in .
def user_logout(request):
    logout(request)

    return HttpResponseRedirect(reverse('LoginApp:index'))

