from django.conf.urls.static import static


#For img showing(3 import needs)
from django.conf import settings
from django.contrib.staticfiles.urls import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

from django.urls import path
from LoginApp import views

app_name= 'LoginApp'

urlpatterns = [
    path('',views.index,name='index'),
    path('register/',views.register, name='register'),
    path('login/',views.login_page,name='login_page'),
    path('user_login/',views.user_login,name='user_login'),
    path('logout/',views.user_logout,name='logout'),
    
]

# urlpatterns+= staticfiles_urlpatterns()
# urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


urlpatterns += staticfiles_urlpatterns()  # Add parentheses here
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)  # Add parentheses here