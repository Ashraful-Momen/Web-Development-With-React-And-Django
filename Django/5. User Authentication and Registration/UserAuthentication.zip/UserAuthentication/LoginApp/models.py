from django.db import models
from django.contrib.auth.models import User

class UserInfo(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    facebookId = models.URLField(blank=True)
    profile_pic = models.ImageField(upload_to='profile_pic', blank=True)

    def __str__(self):
        return self.user.username




# from django.db import models

# from django.contrib.auth.models import User

# class UserInfo(models.Model):

#     user = models.OneToOneField(User, on_delete=models.CASCADE)

#     facebookId = models.URLField(blank=True)

#     profile_pic = models.ImageField(upload_to='profile_pic',blank=True) #img Upload folder name=> profile_pic.

#     def __str__(self):
#         return self.user.username  