from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # Keep your existing index URL
    path('add_album/',views.album_form, name='album_form'),
    path('add_musician/',views.musician_form, name='musician_form'),
]
