from django.shortcuts import render
from django.http import HttpResponse
from first_app.models import Musician, Album
from first_app import forms



#Read => Crud:------------------------------
def index(request):
    musician = Musician.objects.order_by('first_name')
    album = Album.objects.order_by('name')
    
    dictionary={'title':"Home Page","musician_list":musician,'album_list':album}
    return render(request,'first_app/index.html',context=dictionary)

def album_list(request):
    dictionary={"title":'Show Album Page'}
    return render(request,'first_app/album_list.html',context=dictionary)

#create => Crud:---------------------------------------

def musician_form(request):
    form = forms.MusicianForm() #create an object from first_app/forms(MusicianForm class)

    if request.method=="POST":
        form = forms.MusicianForm(request.POST)
            
        if form.is_valid():
           form.save(commit=True)
           return index(request)


    dictionary={'title':'Add Musician','musician_form':form}
    return render(request,'first_app/musician_form.html',context=dictionary)

def album_form(request):
    form = forms.AlbumForm()

    if request.method=="POST":
        form = forms.AlbumForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return index(request)
    dictionary={'title':'Add Album','album_form':form}
    return render(request,'first_app/album_form.html',context=dictionary)






# def form(request):
#     new_form = forms.MusicianForm()
#     dictionary={'test_form':new_form,'heading1_form':"Django Default Forms!"}

#     if request.method == 'POST':
#         new_form = forms.MusicianForm(request.POST)
       

#         if new_form.is_valid():
#             new_form.save(commit=True) # form field save to the DataBase.
#             return index(request) #redirect to index(request) <-views.


#     return render(request, 'first_app/form.html',context=dictionary)