from django import template

register = template.Library()

def my_filter(value,args):
    return value + " This is the custom filter value" + " "+args

register.filter('custom_filter',my_filter)