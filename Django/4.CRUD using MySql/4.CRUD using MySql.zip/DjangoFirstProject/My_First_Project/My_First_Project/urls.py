from django.contrib import admin
from django.urls import path, include
from first_app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('first_app/', include(('first_app.urls', 'first_app'), namespace='first_app')), #user namespace for menu navigations(name of route.).
]





