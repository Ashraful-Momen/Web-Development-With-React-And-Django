from django import forms
from Function_Crud.models import Crud 


class CrudFrom(forms.ModelForm): 
     
     class Meta: 
          model = Crud 
          fields = ['title', 'image', 'description']

    