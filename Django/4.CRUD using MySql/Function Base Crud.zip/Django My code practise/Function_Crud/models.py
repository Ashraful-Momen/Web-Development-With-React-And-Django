from django.db import models

# Create your models here.


class Crud(models.Model): 

    title = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True)
    image = models.ImageField(upload_to='img/', blank=True)
    created = models.DateTimeField(auto_now_add=True) 

    class Meta: 
        ordering = ['-created']

    def __str__(self) -> str:
        return f'title: {self.title}; description: {self.description}'