from django.contrib import admin
from Function_Crud.models import Crud


class CrudAdmin(admin.ModelAdmin):
    list_display = ['title', 'description', 'created']
    verbose_name_plural = 'Function Crud'
    list_filter = ['title', 'description']
    list_per_page =10
    search_fields = ['title', 'description']
    


admin.site.register(Crud, CrudAdmin)