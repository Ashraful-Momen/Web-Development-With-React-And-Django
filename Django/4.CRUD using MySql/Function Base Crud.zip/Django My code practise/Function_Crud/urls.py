from django.urls import path
from django.conf import settings 

from Function_Crud import views

app_name = 'Function_Crud'

urlpatterns = [
    path('fn_create/',views.Create, name='create'),
    path('fn_view/',views.List, name='views'),
    path('fn_edit/<int:id>',views.Edit, name='edit'),
    path('fn_delete/<int:id>',views.Delete, name='delete'),
]
