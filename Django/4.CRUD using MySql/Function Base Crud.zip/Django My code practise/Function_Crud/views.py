from django.shortcuts import render, redirect,HttpResponseRedirect
from django.urls import reverse
from .forms import CrudFrom
from .models import Crud

def Create(request):
    form = CrudFrom()

    if request.method == 'POST':
        form = CrudFrom(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('Function_Crud:views')

    return render(request, 'Function_Crud/create.html', context={ 'form': form})


def List(request): 
    data = Crud.objects.all()

    return render(request,'Function_Crud/views.html',context={'data':data})


def Edit(request, id):
    data = Crud.objects.get(pk=id)
    form = CrudFrom(instance=data)
    dictionary = {'data': data}

    if request.method == "POST":
        print(request.POST) 
        print(request.FILES) 
        form = CrudFrom(request.POST, request.FILES, instance=data)
        if form.is_valid():
            form.save()
            return redirect('Function_Crud:views')

    return render(request, 'Function_Crud/edit.html', context={'dictionary': dictionary, 'form': form,'id':id})



def Delete(request, id): 
    data = Crud.objects.get(pk=id)
    data.delete()

    return redirect('Function_Crud:views') 


