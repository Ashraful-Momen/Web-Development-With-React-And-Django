from django.shortcuts import render
from django.http import HttpResponse
from first_app.models import Musician, Album
from first_app import forms
from django.db.models import Avg 



#Read => Crud:------------------------------
def index(request):
    musician = Musician.objects.order_by('first_name')
   
    
    dictionary={'title':"Home Page","musician_list":musician,}
    return render(request,'first_app/index.html',context=dictionary)


def album_list(request, artist_id):
    artist_info = Musician.objects.get(pk=artist_id) # return one Row according to artist_id
    
    album_info = Album.objects.filter(artist=artist_info).order_by('name','release_date') # **** return more Row according to artist_id . Example=> album_info = Album.objects.filter(foreignKeyName=artist_info)

    #average : the model among all data...
    album_rating_av = Album.objects.filter(artist=artist_id).aggregate(Avg('num_star')) # aggregation : is an operaton on DataBase_Table=> (Average, min, max etc)
    
    dictionary = {"title": 'Show Album Page', 'artist_info': artist_info, 'album_info': album_info, 'album_rating_av':album_rating_av}
    return render(request, 'first_app/album_list.html', context=dictionary)


# def album_list(request,artist_id):
    
#     artist_info=Musician.objects.get(pk=artist_id) # return one Row according to artist_id
    
#     album_info = Album.objects.filter(pk=artist_id) # return more Row according to artist_id
    
#     dictionary={"title":'Show Album Page', 'artist_info':artist_info, 'album_info':album_info}
#     return render(request,'first_app/album_list.html',context=dictionary)

#create => Crud:---------------------------------------

def musician_form(request):
    form = forms.MusicianForm() #create an object from first_app/forms(MusicianForm class)

    if request.method=="POST":
        form = forms.MusicianForm(request.POST)
            
        if form.is_valid():
           form.save(commit=True)
           return index(request)


    dictionary={'title':'Add Musician','musician_form':form}
    return render(request,'first_app/musician_form.html',context=dictionary)

def album_form(request):
    form = forms.AlbumForm()

    if request.method=="POST":
        form = forms.AlbumForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return index(request)
    dictionary={'title':'Add Album','album_form':form}
    return render(request,'first_app/album_form.html',context=dictionary)

#Update: -------------------------------------------------------------

def edit_artist(request,artist_id):
    artist_info= Musician.objects.get(pk=artist_id)
    form = forms.MusicianForm(instance=artist_info) # Musician, forms.MusicianForm both are comes form same models => use (instance -> load the form with model data, for editing)
    dictionary={'musician_form':form}
    
    if request.method=='POST':
        form=forms.MusicianForm(request.POST, instance=artist_info)
        
        if form.is_valid():
            form.save(commit=True)
            return album_list(request,artist_id)
    return render(request,'first_app/edit_artist.html',context=dictionary)

def edit_album(request,album_id):
    album_info = Album.objects.get(pk=album_id)
    form = forms.AlbumForm(instance=album_info)
    dictionary={}
    
    if request.method=="POST":
        form = forms.AlbumForm(request.POST, instance=album_info)
        
        if form.is_valid():
            form.save(commit=True)
            dictionary.update({'success_text':"Successfull Updated"})
            return album_list(request,album_info.artist_id)
    
    dictionary.update({'update_form':form})
    return render(request,'first_app/edit_album.html',context=dictionary)

#delete--------------------------------------

def delete(request,album_id):
    album = Album.objects.get(pk=album_id).delete()
    
    dictionary={'delete':"Successfully delete album"}
    return render(request,'first_app/delete.html',context=dictionary)

def delete_artist(request,artist_id):
    artist = Musician.objects.get(pk=artist_id).delete()
    dictionary={'delete':"Successfully delete artist"}
    return render(request,'first_app/delete.html',context=dictionary)



# def form(request):
#     new_form = forms.MusicianForm()
#     dictionary={'test_form':new_form,'heading1_form':"Django Default Forms!"}

#     if request.method == 'POST':
#         new_form = forms.MusicianForm(request.POST)
       

#         if new_form.is_valid():
#             new_form.save(commit=True) # form field save to the DataBase.
#             return index(request) #redirect to index(request) <-views.


#     return render(request, 'first_app/form.html',context=dictionary)