from django.db import models
from django.urls import reverse

# Create your models here.

class Musician(models.Model):
    # id=models.AutoField(primary_key=True) #this line django take autometically
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    instrument = models.CharField(max_length=50)

    #show the variable :
    def __str__(self):
        return self.first_name+" "+self.last_name
    
    def get_absolute_url(self):
        return reverse('first_app:musician_details', kwargs={'pk':self.pk})

class Album(models.Model):
    # id=models.AutoField(primary_key=True) #this line django take autometically
    artist = models.ForeignKey('Musician',on_delete=models.CASCADE,related_name='album_list') #ForeignKey add , related name ='album_list' can be used in template for access album details info through the model data ....
    name = models.CharField(max_length=50)
    release_date = models.DateField()

    #rating opetions:
    rating=(
        (1,"Bad"),
        (2,"Not Bad"),
        (3,"Good"),
        (4,"Very Good"),
        (5,"Awesome"),
    )
    num_star = models.IntegerField(choices=rating) #add rating option here


    # #change the database table name: better for no changing the table name ... cz when migrate then auto django create the table name.
    # class Meta:
    #     db_table = 'album'

     #show the variable :
    def __str__(self):
        return self.name+" ,Rating:  "+str(self.num_star)+"date"+str(self.release_date)


