from typing import Any, Dict


#Import for Class based Views:--------------------------------------

from django.views.generic import View  #for classbased view... work for => return HttpResponse("I am from class views")
from django.views.generic import TemplateView #work for view a template

from first_app import models #import models before use =>ListView 
from django.views.generic import ListView # Model data's convert into list then pass to template.html
from django.views.generic import DetailView #return Details info for model 1 row but need primaryKey....

from django.views.generic import CreateView #Create / Add data to model
from django.views.generic import UpdateView #Update / update view
from django.views.generic import DeleteView #Delete view
from django.urls import reverse_lazy #redirect any template.html when delete task successfully...



#Class Based View ---------------------------------------------------


#CRUD(CBV): READ-------------------------------------------

class IndexView(ListView): #class can inherit 1 impoter at a time (View/TemplateView/ListView)

    context_object_name = 'musician_list' #'musician_list' varibale store the 'model' varibale's data and pass to template.html
    
    model = models.Musician #import Musican from Model

    template_name = 'first_app/index.html'

    # (default's class varibale=> template_name,context_object_name)




    # def get_context_data(self, **kwargs: Any) :  #buildin class : context return dictionary's values

    #     context = super().get_context_data(**kwargs)
    #     context ['text1'] = "Simple text1"
    #     context ['text2'] = "Simple text2"
    #     return context

    # def get(self, request):
    #     return HttpResponse("I am from class views")

class MusicianDetails(DetailView):

    context_object_name = 'musician'

    model = models.Musician

    template_name = 'first_app/musician_details.html'
    

# CREATE -----------------------------------------------------

class AddMusician(CreateView):

    fields=('first_name','last_name','instrument')
    # fields='__all__'

    model = models.Musician
    
    template_name = 'first_app/add_musician.html'

class UpdateMusician(UpdateView): #no need any template , it's used exiting AddMusician(class template)

    fields= ('first_name','last_name','instrument')

    model = models.Musician

    template_name = 'first_app/add_musician.html'

class DeleteMusician(DeleteView):

    context_object_name = 'musician'

    model = models.Musician

    success_url = reverse_lazy('first_app:index')

    template_name = 'first_app/delete_musician.html'


