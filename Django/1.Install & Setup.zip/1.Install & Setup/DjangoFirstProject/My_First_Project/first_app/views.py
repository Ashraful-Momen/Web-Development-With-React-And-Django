from django.shortcuts import render
from django.http import HttpResponse



def index(request):
    dictionary ={"name":"shuvo",}
    return render(request,'first_app/index.html',context=dictionary)

