from django.db import models

# Create your models here.

class Musician(models.Model):
    # id=models.AutoField(primary_key=True) #this line django take autometically
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    instrument = models.CharField(max_length=50)

    #show the variable :
    def __str__(self):
        return self.first_name+" "+self.last_name

class Album(models.Model):
    # id=models.AutoField(primary_key=True) #this line django take autometically
    artist = models.ForeignKey('Musician',on_delete=models.CASCADE) #ForeignKey add
    name = models.CharField(max_length=50)
    release_date = models.DateField()

    #rating opetions:
    rating=(
        (1,"Bad"),
        (2,"Not Bad"),
        (3,"Good"),
        (4,"Very Good"),
        (5,"Awesome"),
    )
    num_star = models.IntegerField(choices=rating) #add rating option here

     #show the variable :
    def __str__(self):
        return self.name+" ,Rating:  "+str(self.num_star)+"date"+str(self.release_date)


