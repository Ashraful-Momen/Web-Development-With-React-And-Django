from django.shortcuts import render
from django.http import HttpResponse
from first_app.models import Musician, Album
from first_app import forms
from django.utils.formats import date_format
from datetime import datetime

def index(request):
    album = Album.objects.get(pk=2)
    formatted_date = date_format(album.release_date, 'SHORT_DATE_FORMAT')
     # Convert the formatted date string to a datetime object
    formatted_date_datetime = datetime.strptime(formatted_date, '%m/%d/%Y')
    dictionary={'sample_text':'I\'m a sample text.', 'additions':'8','formatted_date': formatted_date_datetime,'custom_filter':"call the custom_filter!"} #Album.objects.get(pk=1)=> in Album models have some data with date and primarykey=pk
    
    return render(request,'first_app/index.html',context=dictionary)

def form(request):
    new_form = forms.MusicianForm()
    dictionary={'test_form':new_form,'heading1_form':"Django Default Forms!"}

    if request.method == 'POST':
        new_form = forms.MusicianForm(request.POST)
       

        if new_form.is_valid():
            new_form.save(commit=True) # form field save to the DataBase.
            return index(request) #redirect to index(request) <-views.


    return render(request, 'first_app/form.html',context=dictionary)