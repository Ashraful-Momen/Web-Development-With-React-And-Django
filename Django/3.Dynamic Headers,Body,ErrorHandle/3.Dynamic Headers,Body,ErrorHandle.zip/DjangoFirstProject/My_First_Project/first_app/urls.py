from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # Keep your existing index URL
    path('form/', views.form, name='form'),  # Keep your existing form URL
]
