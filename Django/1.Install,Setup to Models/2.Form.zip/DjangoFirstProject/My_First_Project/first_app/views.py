from django.shortcuts import render
from django.http import HttpResponse
from first_app.models import Musician, Album
from first_app import forms

def index(request):
    # SELECT * FROM Musician ORDER BY first_name #raw MySQL query
    musician_list = Musician.objects.order_by('first_name') #ORM
    dictionary ={"Musician_List":"All Musician's","musician":musician_list}
    return render(request,'first_app/index.html',context=dictionary)

def form(request):
    new_form = forms.MusicianForm()
    dictionary={'test_form':new_form,'heading1_form':"Django Default Forms!"}

    if request.method == 'POST':
        new_form = forms.MusicianForm(request.POST)
       

        if new_form.is_valid():
            new_form.save(commit=True) # form field save to the DataBase.
            return index(request) #redirect to index(request) <-views.


    return render(request, 'first_app/form.html',context=dictionary)