
from django import forms
from first_app import models

class MusicianForm(forms.ModelForm):
    class Meta:
        model = models.Musician
        fields = "__all__"  # Corrected attribute name
      #   fields = ('first_name','last_name') # if we need some field then use this line.
      #   exclude = ['first_name','last_name'] # if we need without this two fields then use this line.


