from django.urls import path
from App_Login import views


app_name='App_Login'

urlpatterns = [
    path('singup/',views.sing_up,name='sing_up'),
    path('login/',views.log_in,name='login'),
    path('logout/',views.log_out,name='logout')
    
]
