from django.shortcuts import render
from django.contrib.auth.forms import  AuthenticationForm, PasswordChangeForm
from django.contrib.auth import login,authenticate,logout
from django.shortcuts import HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from App_Login.forms import SignUpForm, UserProfileChange, ProfilePic




def sing_up(request):
    form = SignUpForm()
    registered = False
    
    if request.method=='POST':
        form = SignUpForm(data=request.POST)
        if form.is_valid():
            form.save()
            registered = True
            
    dictionary = {'form':form, 'registered':registered}
    
    return render(request,'App_Login/sing_up.html',context=dictionary)


def log_in(request):
    form = AuthenticationForm()
    
    if request.method=="POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            username= form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            
            user = authenticate(username=username,password=password)
            
            if user is not None: #if user exit in DataBase
                login(request,user)
                
                return HttpResponseRedirect(reverse('index'))
    
    return render(request,'App_Login/login.html',context={'form':form})

@login_required
def log_out(request):
    logout(request)
    
    return HttpResponseRedirect(reverse('index'))
    

@login_required 
def profile(request):
    dictionary = {}
    return render(request,'App_Login/profile.html',context=dictionary)

#edit user profile
@login_required
def user_change(request):
    current_user = request.user #this data comes from Model and  request.user <- this user is a global varibale , when user create profile then this varibale generated...
    form = UserProfileChange(instance=current_user)  #store runnig user valude from Model
    
    if request.method=='POST':
        form = UserProfileChange(request.POST, instance=current_user) #UserProfileChange(runnig data get from template, Model data )
        if form.is_valid():
            form.save()
            form = UserProfileChange(instance=current_user) #get the changing value form Model
        
    return render(request,'App_Login/change_profile.html',context={'form':form})

@login_required 
def passwd_change(request):
    changed= False
    current_user = request.user
    form = PasswordChangeForm(current_user)
    
    if request.method=='POST':
        form = PasswordChangeForm(current_user, data=request.POST)
        if form.is_valid():
            form.save()
            changed=True
    return render(request,'App_Login/password_change.html',context={'form':form,'changed':changed})


# @login_required
# def add_pro_pic(request): #add profile pic.
#     form = ProfilePic()
#     if request.method == 'POST':
#         form = ProfilePic(request.POST, request.FILES)
#         if form.is_valid():
#             user_obj= form.save(commit=False)
#             user_obj.user = request.user #select the user from model = current login user, cz in model 2 fields, 1 is user, 2 is profile_pic 
#             user_obj.save(commit=True)
#             return HttpResponseRedirect(reverse('App_Login:profile'))
            
#     return render(request,'App_Login/pro_pic_add.html',context={'form':form})



@login_required
def add_pro_pic(request):
    if request.method == 'POST':
        form = ProfilePic(request.POST, request.FILES)
        if form.is_valid():
            user_obj = form.save(commit=False)
            user_obj.user = request.user
            user_obj.save()
            return HttpResponseRedirect(reverse('App_Login:profile'))
    else:  # Handling the GET request case
        form = ProfilePic()

    return render(request, 'App_Login/pro_pic_add.html', context={'form': form})


@login_required
def change_pro_pic(request):
    if request.method == "POST":
        form = ProfilePic(request.POST, request.FILES, instance=request.user.user_profile)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('App_Login:profile'))
    else:  # Handling the GET request case
        form = ProfilePic(instance=request.user.user_profile)
    
    return render(request, 'App_Login/pro_pic_add.html', context={'form': form})
