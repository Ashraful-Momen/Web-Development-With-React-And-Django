from django.urls import path 
from App_Blog import views


#if use namespace than , not need to use => app_name = "App_Blog"

urlpatterns = [
    path('',views.BlogList.as_view(),name='blog_list'),
    path('write/',views.CreateBlog.as_view(),name='create_blog'),
    path('details/<slug:slug>/',views.BlogDetails, name='details_blog'),
    path('like/<pk>',views.like,name='like_post'),
    path('unlike/<pk>',views.unlike,name='unlike_post'),
    path('my_blogs/',views.MyBlog.as_view(),name='my_blog'),
    path('edit_blog/<int:pk>/', views.UpdateBlog.as_view(), name='edit_blog'),
    # path('edit_blog/<pk>',views.UpdateBlog.as_view(),name='edit_blog'),
    
]
