from django import template

register=template.Library()

def range_fillter(value):
    return value[:500] + '.....'

register.filter('range_filter',range_fillter)