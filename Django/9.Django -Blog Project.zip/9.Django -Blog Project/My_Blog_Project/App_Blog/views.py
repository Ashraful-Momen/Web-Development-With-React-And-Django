from django.shortcuts import render,HttpResponseRedirect
from django.urls import reverse,reverse_lazy 
from django.views.generic import ListView,View,TemplateView,CreateView,UpdateView,DetailView,DeleteView
from App_Blog.models import Blog,Comment,Like
from django.contrib.auth.decorators import login_required #for functional views only
from django.contrib.auth.mixins import LoginRequiredMixin #for Classbased views only
import uuid

from App_Blog.forms import CommentForm



#show user's own blogs : ---------------------------------------

class MyBlog(LoginRequiredMixin, TemplateView):

    template_name = 'App_Blog/my_blog.html'


# create Blogs:-------------------------------------------------

from django.utils.text import slugify
import uuid

class CreateBlog(LoginRequiredMixin, CreateView):
    model = Blog
    fields = ('blog_title', 'blog_content', 'blog_image')
    template_name = 'App_Blog/create_blog.html'
    
    def form_valid(self, form):
        blog_obj = form.save(commit=False)
        blog_obj.author = self.request.user
        
        # Generate a unique slug based on the title
        title = blog_obj.blog_title
        base_slug = slugify(title)
        unique_slug = base_slug + "-" + str(uuid.uuid4())[:8]
        blog_obj.slug = unique_slug
        
        
        
        blog_obj.save()
        return HttpResponseRedirect(reverse('index'))








#Read Blog---------------------------------------------------------

class BlogList(ListView):
    
    context_object_name = 'blogs'
    model =Blog 
    template_name = 'App_Blog/blog_list.html'
    # queryset = Blog.objects.order_by('-publish_date') # show the update blog


@login_required
def BlogDetails(request, slug):
    blog = Blog.objects.get(slug=slug)

    already_like = Like.objects.filter(user=request.user, blog=blog)
    if already_like:
        liked = True
    else:
        liked = False

    if request.method == 'POST':
        comment_form = CommentForm(request.POST)  # Create an instance of CommentForm
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.user = request.user
            comment.blog = blog
            comment.save()
            return HttpResponseRedirect(reverse('App_Blog:details_blog', kwargs={'slug':slug}))
    else:
        comment_form = CommentForm()  # Create a new instance of CommentForm for GET requests

    return render(request, 'App_Blog/blog_details.html', context={'blog':blog, 'comment_form':comment_form, 'liked':liked})





class UpdateBlog(LoginRequiredMixin, UpdateView):
    model = Blog
    fields = ('blog_title','blog_content','blog_image')
    template_name = 'App_Blog/edit_blog.html'

    def get_success_url(self):
        return reverse_lazy('App_Blog:details_blog', kwargs={'slug': self.object.slug})




@login_required
def like(request,pk):
    blog = Blog.objects.get(pk=pk)
    user = request.user
    already_like = Like.objects.filter(user=user,blog=blog)
    if not already_like:
        like_post = Like(user=user,blog=blog)
        like_post.save()
    return HttpResponseRedirect(reverse('App_Blog:details_blog', kwargs={'slug':blog.slug}))

@login_required
def unlike(request,pk):
    blog = Blog.objects.get(pk=pk)
    user = request.user
    already_like = Like.objects.filter(user=user,blog=blog)
    already_like.delete()
    return HttpResponseRedirect(reverse('App_Blog:details_blog', kwargs={'slug':blog.slug}))

