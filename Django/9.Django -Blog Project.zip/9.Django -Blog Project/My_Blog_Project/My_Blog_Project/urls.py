from django.contrib import admin
from django.urls import path, include
from App_Blog import urls
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('account/', include('App_Login.urls')),
    path('blog/', include(('App_Blog.urls','App_Blog'),namespace='App_Blog')),
    path('', views.index, name='index'),
]



# from django.contrib import admin
# from django.urls import path,include
# from App_Blog import urls
# from . import views
# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('account/',include('App_Login.urls')),
#     # path('blog/',include('App_Blog.urls')), #another way => path('blog/', include('App_Blog.url','App_Blog'),namespace('App_Blog'))
#     path('blog/',include('App_Blog.urls',namespace='App_Blog')),
#     path('',views.index,name='index'),
# ]
