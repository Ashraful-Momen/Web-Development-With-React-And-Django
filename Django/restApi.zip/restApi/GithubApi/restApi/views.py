from django.shortcuts import render
import requests



def index(requst):
    user = False
    
   
    
    if requst.method == "POST":
        username = requst.POST.get('user_name')
        # url = "https://api.github.com/"+str(username)
        url = "https://api.github.com/users/%s" % username
        response = requests.get(url)
        
        user = response.json()
    
    dictionary={'user':user}
    
    return render(requst,'restApi/index.html',context=dictionary)
